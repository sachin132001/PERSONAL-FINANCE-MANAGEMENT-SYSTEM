package entity;

public class TodoDtls {
	private int id;
	private int userId;
	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	private String todo;
	private String description;
	private String target_date;
	private String status;
	
	
	public TodoDtls(int id,int userId,  String todo, String description, String target_date, String status) {
		super();
		this.id=id;
		this.userId = userId;
		this.todo = todo;
		this.description = description;
		this.target_date = target_date;
		this.status = status;
		
	}

	public int getId() {
		return id;
	}
	
	
	public String getTarget_date() {
		return target_date;
	}

	public void setTarget_date(String target_date) {
		this.target_date = target_date;
	}

	
	
	public TodoDtls() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public void setId(int id) {
		this.id = id;
	}

	public String getTodo() {
		return todo;
	}

	public void setTodo(String todo) {
		this.todo = todo;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "TodoDtls [id=" + id + ", user_id=" + userId + ", todo=" + todo + ", description=" + description
				+ ", target_date=" + target_date + ", status=" + status + "]";
	}

	
	

	
}
