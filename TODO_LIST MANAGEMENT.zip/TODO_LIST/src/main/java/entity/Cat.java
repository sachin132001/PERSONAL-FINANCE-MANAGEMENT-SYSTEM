package entity;

public class Cat {
	private int id;
	private int userId;
	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}
	private String cat_desc;
	
	public Cat(int id,int userId,  String cat_desc) {
		super();
		this.id=id;
		this.userId = userId;
		this.cat_desc = cat_desc;
		
	}
	public int getId() {
		return id;
	}

	public Cat() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCat_desc() {
		return cat_desc;
	}

	public void setCat_desc(String cat_desc) {
		this.cat_desc = cat_desc;
	}
	@Override
	public String toString() {
		return "Cat [id=" + id + ", userId=" + userId + ", cat_desc=" + cat_desc + "]";
	}


}
