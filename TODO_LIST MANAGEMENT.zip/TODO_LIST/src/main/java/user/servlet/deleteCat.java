package user.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.CatDAO;
import database.DBConnect;

@WebServlet("/deletecat")
public class deleteCat extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		int id=Integer.parseInt(req.getParameter("id"));
		
		CatDAO dao = new CatDAO(DBConnect.getConn());
		boolean f=dao.deleteCat(id);
		HttpSession session = req.getSession();

		if (f) {
			session.setAttribute("sucMsg", "TODO delete Sucessfully..");
			resp.sendRedirect("view2.jsp");
		} else {
			session.setAttribute("errMsg", "something wrong on server");
			resp.sendRedirect("view2.jsp");
		}
		

	}

}