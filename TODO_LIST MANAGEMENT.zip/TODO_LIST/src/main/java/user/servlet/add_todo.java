package user.servlet;

	import java.io.IOException;

	import javax.servlet.ServletException;
	import javax.servlet.annotation.WebServlet;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;
	import javax.servlet.http.HttpSession;

	import dao.TodoDAO;
	import database.DBConnect;
	import entity.TodoDtls;

	@WebServlet("/add_todo")
	public class add_todo extends HttpServlet {

		@Override
		protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

			try {
				int userId = Integer.parseInt(req.getParameter("userid"));
				String todo = req.getParameter("todo");
				String description = req.getParameter("description"); 
				String target_date=req.getParameter("target_date");
				String status = req.getParameter("status");


				TodoDAO dao = new TodoDAO(DBConnect.getConn());
				boolean f=dao.add_todo(userId,todo,description,target_date,status);
				HttpSession session = req.getSession();

				if (f) {
					session.setAttribute("sucMsg", "TODO Added Sucessfully..");
					resp.sendRedirect("view.jsp");
				} else {
					session.setAttribute("errMsg", "something wrong on server");
					resp.sendRedirect("view.jsp");
				}

			} catch (Exception e) {
				e.printStackTrace();
			}

		}


}
