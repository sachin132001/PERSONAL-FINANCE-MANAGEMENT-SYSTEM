package user.servlet;

	import java.io.IOException;

	import javax.servlet.ServletException;
	import javax.servlet.annotation.WebServlet;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;
	import javax.servlet.http.HttpSession;

	import dao.CatDAO;
	import database.DBConnect;
	import entity.Cat;

	@WebServlet("/add_cat")
	public class add_cat extends HttpServlet {

		@Override
		protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

			try {
				int userId = Integer.parseInt(req.getParameter("userid"));
				String cat_desc = req.getParameter("cat_desc");
				

				CatDAO dao = new CatDAO(DBConnect.getConn());
				boolean f=dao.add_cat(userId,cat_desc);
				HttpSession session = req.getSession();

				if (f) {
					session.setAttribute("sucMsg", "TODO Added Sucessfully..");
					resp.sendRedirect("view2.jsp");
				} else {
					session.setAttribute("errMsg", "something wrong on server");
					resp.sendRedirect("view2.jsp");
				}

			} catch (Exception e) {
				e.printStackTrace();
			}

		}


}
