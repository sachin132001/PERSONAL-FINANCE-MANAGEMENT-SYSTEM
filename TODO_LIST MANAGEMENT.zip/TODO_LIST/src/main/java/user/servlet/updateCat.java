package user.servlet;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import dao.CatDAO;
import database.DBConnect;

import entity.Cat;


	@WebServlet("/updateCat")
	public class updateCat extends HttpServlet {

		@Override
		protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

			try {
				int userId = Integer.parseInt(req.getParameter("userid"));
				String cat_desc = req.getParameter("cat_desc");
				
				
				int id = Integer.parseInt(req.getParameter("id"));
				

				Cat c = new Cat(id,userId,cat_desc);

				CatDAO dao = new CatDAO(DBConnect.getConn());
				HttpSession session = req.getSession();

				if (dao.updateCat(c)) {
					session.setAttribute("sucMsg", "Todo Update Sucessfully..");
					resp.sendRedirect("view2.jsp");
				} else {
					session.setAttribute("errMsg", "something wrong on server");
					resp.sendRedirect("view2.jsp");
				}



			} catch (Exception e) {
				e.printStackTrace();
			}
	}
	}

		
	


