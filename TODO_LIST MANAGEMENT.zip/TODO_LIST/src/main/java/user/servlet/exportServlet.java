package user.servlet;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.poi.sl.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import dao.TodoDAO;
import database.DBConnect;
import entity.TodoDtls;
import entity.User;

@WebServlet("/exportServlet")
public class exportServlet extends HttpServlet {
    
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        // Get the todo list from the database
        User user = (User) request.getSession().getAttribute("userObj");
        TodoDAO todoDAO = new TodoDAO(DBConnect.getConn());
        List<TodoDtls> todoList = todoDAO.getAllTodoDtlsByLoginUser(user.getId());
        
        // Create a new Excel workbook
        Workbook workbook = new XSSFWorkbook();
        org.apache.poi.ss.usermodel.Sheet sheet = workbook.createSheet("Todo List");
        int rowNum = 0;
        
        // Create header row
        Row headerRow = ((org.apache.poi.ss.usermodel.Sheet) sheet).createRow(rowNum++);
        headerRow.createCell(0).setCellValue("ID");
        headerRow.createCell(1).setCellValue("TODO");
        headerRow.createCell(2).setCellValue("DESCRIPTION");
        headerRow.createCell(3).setCellValue("TARGET DATE");
        headerRow.createCell(4).setCellValue("STATUS");
        
        // Fill data rows
        for (TodoDtls todo : todoList) {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(todo.getId());
            row.createCell(1).setCellValue(todo.getTodo());
            row.createCell(2).setCellValue(todo.getDescription());
            row.createCell(3).setCellValue(todo.getTarget_date());
            row.createCell(4).setCellValue(todo.getStatus());
        }
        
        // Set response headers
        response.setContentType("application/vnd.ms-excel");
        response.setHeader("Content-Disposition", "attachment; filename=todo_list.xlsx");
        
        // Write workbook to output stream
        OutputStream out = response.getOutputStream();
        workbook.write(out);
        workbook.close();
        out.close();
    }
}