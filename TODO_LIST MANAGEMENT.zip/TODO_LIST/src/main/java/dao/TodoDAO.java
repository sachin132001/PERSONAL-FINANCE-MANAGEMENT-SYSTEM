package dao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import entity.TodoDtls;
public class TodoDAO {
		private Connection conn;

		public TodoDAO(Connection conn) {
			super();
			this.conn = conn;
		}

		public boolean add_todo(int userId, String todo,String description,String target_date,String status) {
			boolean f = false;

			try {
				String sql = "insert into add_todo(user_id,todo,description,target_date,status) values(?,?,?,?,?)";
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setInt(1, userId);
				ps.setString(2, todo);
				ps.setString(3, description);
				ps.setString(4, target_date);
				ps.setString(5, status);
				
				int i = ps.executeUpdate();
				if (i == 1) {
					f = true;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			return f;
		}
		
		public List<TodoDtls> getAllTodoDtlsByLoginUser(int userId)
		{
			List<TodoDtls> list = new ArrayList<TodoDtls>();
			TodoDtls t = null;
			try {

				String sql = "select * from add_todo where user_id=?";
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setInt(1, userId);

				ResultSet rs = ps.executeQuery();
				while (rs.next()) {
					t = new TodoDtls();
				//	t.setUserId(rs.getInt(1));
					t.setId(rs.getInt(1));
			        t.setUserId(rs.getInt(2));
					t.setTodo(rs.getString(3));
					t.setDescription(rs.getString(4));
					t.setTarget_date(rs.getString(5));
					t.setStatus(rs.getString(6));
					
					list.add(t);
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
			return list;
		}
		public List<TodoDtls> getCompletedTodos(int userId) {
		    List<TodoDtls> todo = new ArrayList<>();
		   
		    TodoDtls d = null;
			try {
				String sql = "SELECT * FROM add_todo WHERE user_id = ? AND status='complete'";
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setInt(1, userId);

				ResultSet rs = ps.executeQuery();
				while (rs.next()) {
					d = new TodoDtls();
				//	t.setUserId(rs.getInt(1));
					d.setId(rs.getInt(1));
			        d.setUserId(rs.getInt(2));
					d.setTodo(rs.getString(3));
					d.setDescription(rs.getString(4));
					d.setTarget_date(rs.getString(5));
					d.setStatus(rs.getString(6));
					
					todo.add(d);
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
			return todo;
		}
		public List<TodoDtls> getPendingTodos(int userId) {
		    List<TodoDtls> todo = new ArrayList<>();
		   
		    TodoDtls d = null;
			try {
				String sql = "SELECT * FROM add_todo WHERE user_id = ? AND status='pending'";
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setInt(1, userId);

				ResultSet rs = ps.executeQuery();
				while (rs.next()) {
					d = new TodoDtls();
				//	t.setUserId(rs.getInt(1));
					d.setId(rs.getInt(1));
			        d.setUserId(rs.getInt(2));
					d.setTodo(rs.getString(3));
					d.setDescription(rs.getString(4));
					d.setTarget_date(rs.getString(5));
					d.setStatus(rs.getString(6));
					
					todo.add(d);
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
			return todo;
		}
		public List<TodoDtls> getOverdueTodos(int userId) {
		    List<TodoDtls> todo = new ArrayList<>();
		    TodoDtls d = null;
		    try {
		        String sql = "SELECT * FROM add_todo WHERE user_id = ? AND target_date < CURDATE() AND status != 'complete'";
		        PreparedStatement ps = conn.prepareStatement(sql);
		        ps.setInt(1, userId);
		        ResultSet rs = ps.executeQuery();
		        while (rs.next()) {
		            d = new TodoDtls();
		            d.setId(rs.getInt(1));
		            d.setUserId(rs.getInt(2));
		            d.setTodo(rs.getString(3));
		            d.setDescription(rs.getString(4));
		            d.setTarget_date(rs.getString(5));
		            d.setStatus(rs.getString(6));
		            todo.add(d);
		        }
		    } catch (Exception e) {
		        e.printStackTrace();
		    }
		    return todo;
		}
		


		public TodoDtls getTodoById(int id) {

			TodoDtls t = null;
			try {

				String sql = "select * from add_todo where id=?";
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setInt(1, id);
				ResultSet rs = ps.executeQuery();

				while (rs.next()) {
					t = new TodoDtls();
					
					t.setId(rs.getInt(1));
					t.setUserId(rs.getInt(2));
					t.setTodo(rs.getString(3));
					t.setDescription(rs.getString(4));
					t.setTarget_date(rs.getString(5));
					t.setStatus(rs.getString(6));
					

				}

			} catch (Exception e) {
				e.printStackTrace();
			}
			return t;
		}
		
		public boolean updateTodo(TodoDtls t) {
			boolean f = false;

			try {
				String sql = "update add_todo set user_id=?, todo=?,description=?,target_date=?,status=? where id=?";
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setInt(1, t.getUserId());
				ps.setString(2, t.getTodo());
				ps.setString(3, t.getDescription());
				ps.setString(4, t.getTarget_date());
				ps.setString(5, t.getStatus());
				ps.setInt(6, t.getId());
				
				int i = ps.executeUpdate();
				if (i == 1) {
					f = true;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			return f;
		}

		public boolean deleteTodo(int id) {
			boolean f = false;
			try {
				String sql = "delete from add_todo where id=?";
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setInt(1, id);

				int i = ps.executeUpdate();
				if (i == 1) {
					f = true;
				}

			} catch (Exception e) {
				e.printStackTrace();
			}

			return f;
		}
		


}
