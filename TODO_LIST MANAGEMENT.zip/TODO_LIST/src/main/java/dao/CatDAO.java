package dao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import entity.Cat;

public class CatDAO {
	private Connection conn;

	public CatDAO(Connection conn) {
		super();
		this.conn = conn;
	}
	public boolean add_cat(int userId, String cat_desc) {
		boolean f = false;

		try {
			String sql = "insert into add_cat(user_id,cat_desc) values(?,?)";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, userId);
			ps.setString(2, cat_desc);
			
			
			int i = ps.executeUpdate();
			if (i == 1) {
				f = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return f;
	}
	public List<Cat> getAllCatByLoginUser(int userId)
	{
		List<Cat> list = new ArrayList<Cat>();
		Cat c = null;
		try {

			String sql = "select * from add_cat where user_id=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, userId);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				c = new Cat();
			//	t.setUserId(rs.getInt(1));
				c.setId(rs.getInt(1));
		        c.setUserId(rs.getInt(2));
				c.setCat_desc(rs.getString(3));
				
				list.add(c);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	public Cat getCatById(int id) {

		Cat c = null;
		try {

			String sql = "select * from add_cat where id=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				c = new Cat();
				
				c.setId(rs.getInt(1));
				c.setUserId(rs.getInt(2));
				c.setCat_desc(rs.getString(3));
				

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return c;
	}
	
	public boolean updateCat(Cat c) {
		boolean f = false;

		try {
			String sql = "update add_cat set user_id=?, cat_desc=? where id=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, c.getUserId());
			ps.setString(2, c.getCat_desc());
			ps.setInt(6, c.getId());
			
			int i = ps.executeUpdate();
			if (i == 1) {
				f = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return f;
	}

	public boolean deleteCat(int id) {
		boolean f = false;
		try {
			String sql = "delete from add_cat where id=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, id);

			int i = ps.executeUpdate();
			if (i == 1) {
				f = true;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return f;
	}
	


	

}
